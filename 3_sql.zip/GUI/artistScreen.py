import sys
import sqlite3
import uuid
from PyQt5 import QtWidgets

def error_msg(str):
    error_str_line = "\n************************\n"
    print(error_str_line + str + error_str_line)

def info_msg(str):
    info_str_line = "\n-------------------------\n"
    print(info_str_line + str + info_str_line)


class artistScreen():
    def __init__(self, db, cursor, aid) -> None:
        self.db = db
        self.cursor = cursor
        self.aid = aid
        
        self.main_screen()
        
    def main_screen(self):
        while True:
            print('''
                        ==============Artist Screen=================
                        |   [1.Add a song                       ]  |
                        |   [2.Find top fans and playlists      ]  |
                        |   [3.Logout                           ]  |
                        ============================================
                        ''')

            try:
                option = int(input('Please enter the option you want to choose(1/2):'))
            except ValueError:
                error_msg("Error: Invalid input")
                option = int(input('Please enter the option you want to choose(1/2):'))
            
            if option == 1:
                title = input("The title of the song:")
                while len(title) == 0 or title.isspace():
                    error_msg("Error: Invalid title!")
                    title = input("The title of the song:")
                
                duration = input("The duration of the song:")
                while not duration.isnumeric() or duration.isspace() or len(duration) == 0:
                    error_msg("Error: Invalid duration, which should be an int")
                    duration = input("The duration of the song:")
                    
                sql = u"select * from perform left join songs on perform.sid=songs.sid where aid='{}' and title='{}' and duration='{}'".format(self.aid, title, duration)
                self.cursor.execute(sql)
                res = self.cursor.fetchall()
                
                if len(res) != 0:
                    error_msg("Warning: The song is already exist")
                    while True:
                        print('''
                            =======Are you sure to add this song?=======
                            |   [1.Confirm                          ]  |
                            |   [2.Cancel                           ]  |
                            ============================================
                            ''')
                        op = int(input("Enter your choice(1/2):"))
                        if op == 1:
                            sid = uuid.uuid1().hex
                            sql = u"insert into songs values('{}', '{}', '{}')".format(sid, title, duration)
                            self.cursor.execute(sql)
                            self.db.commit()
                            
                            sql = u"insert into perform values('{}', '{}')".format(self.aid, sid)
                            self.cursor.execute(sql)
                            self.db.commit()
                            
                            info_msg("Add a song successfully")
                            break
                        elif op == 2:
                            break
                        else:
                            error_msg("Error: Invalid input")
                            continue
                else:
                    sid = uuid.uuid1().hex
                    sql = u"insert into songs values('{}', '{}', '{}')".format(sid, title, duration)
                    self.cursor.execute(sql)
                    self.db.commit()
                    
                    sql = u"insert into perform values('{}', '{}')".format(self.aid, sid)
                    self.cursor.execute(sql)
                    self.db.commit()
                    
                    info_msg("Add a song successfully")
                    break
            elif option == 2:
                sql = u"select name, sum(cnt) as score from users left join listen on users.uid=listen.uid left join perform on listen.sid=perform.sid where aid='{}' group by users.uid order by score desc".format(self.aid)
                self.cursor.execute(sql)
                fans_list = self.cursor.fetchall()
                print("=============Top fans=============")
                for fan in fans_list[0:3]:
                    print(fan[0])
                    
                sql = u"select title, count(perform.sid) as score from playlists left join plinclude on playlists.pid=plinclude.pid left join perform on plinclude.sid=perform.sid where aid='{}' group by playlists.pid order by score desc".format(self.aid)
                self.cursor.execute(sql)
                play_list = self.cursor.fetchall()
                print("=============Top playlist=========")
                for playlist in play_list[0:3]:
                    print(playlist[0])
            elif option == 3:
                return



